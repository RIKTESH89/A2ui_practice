# Official source index

Verified on 2026-09-24. Prefer these first-party sources. Community repositories can provide ideas,
but must not be treated as AndroidX API contracts.

## Android developer documentation

- [A2UI Compose overview](https://developer.android.com/develop/ui/compose/agentic)
- [Create and customize catalogs](https://developer.android.com/develop/ui/compose/agentic/manage-catalogs)
- [Render A2UI surfaces](https://developer.android.com/develop/ui/compose/agentic/render-surfaces)
- [Implement custom A2UI components](https://developer.android.com/develop/ui/compose/agentic/implement-components)
- [A2UI engine/model release notes](https://developer.android.com/jetpack/androidx/releases/a2ui)
- [A2UI Compose release notes](https://developer.android.com/jetpack/androidx/releases/a2ui-compose)
- [Compose Material 3 release notes](https://developer.android.com/jetpack/androidx/releases/compose-material3)
- [Biometric authentication guide](https://developer.android.com/identity/sign-in/biometric-auth)
- [Android app architecture guide](https://developer.android.com/topic/architecture)

## AndroidX source and samples

- [AndroidX A2UI source](https://cs.android.com/androidx/platform/frameworks/support/+/androidx-main:a2ui/)
- [Compose A2UI runtime/UI source](https://cs.android.com/androidx/platform/frameworks/support/+/androidx-main:a2ui/compose/)
- [Material 3 A2UI source and samples](https://cs.android.com/androidx/platform/frameworks/support/+/androidx-main:compose/material3/material3-a2ui/)
- [AndroidX source mirror](https://github.com/androidx/androidx)

For exact published behavior, prefer the alpha01 source/JAR/AAR over `androidx-main`, which can move
ahead of the release.

## A2UI protocol repository

- [A2UI project](https://github.com/a2ui-project/a2ui)
- [v0.9.1 specification snapshot](https://github.com/a2ui-project/a2ui/tree/main/specification/v0_9_1)
- [v0.9.1 server-to-client schema](https://github.com/a2ui-project/a2ui/blob/main/specification/v0_9_1/json/server_to_client.json)
- [v0.9.1 common types](https://github.com/a2ui-project/a2ui/blob/main/specification/v0_9_1/json/common_types.json)
- [v0.9.1 Basic Catalog schema](https://github.com/a2ui-project/a2ui/blob/main/specification/v0_9_1/catalogs/basic/catalog.json)
- [v0.9.1 Basic Catalog guide](https://github.com/a2ui-project/a2ui/blob/main/specification/v0_9_1/docs/basic_catalog_implementation_guide.md)
- [v0.9.1 A2A extension](https://github.com/a2ui-project/a2ui/blob/main/specification/v0_9_1/docs/a2ui_extension_specification.md)
- [Agent development guide](https://github.com/a2ui-project/a2ui/blob/main/docs/public/guides/agent-development.md)
- [Using A2UI with any agent framework](https://github.com/a2ui-project/a2ui/blob/main/docs/public/guides/a2ui-with-any-agent-framework.md)
- [Transport concepts](https://github.com/a2ui-project/a2ui/blob/main/docs/public/concepts/transports.md)
- [Catalog concepts](https://github.com/a2ui-project/a2ui/blob/main/docs/public/concepts/catalogs.md)
- [ADK agent samples](https://github.com/a2ui-project/a2ui/tree/main/samples/agent/adk)

The repository was inspected at commit `a204b8a7824c6ef523ba6470369990774e21e5b9` for this package.
Because `main` can evolve, pin or vendor the compatible v0.9.1 schemas in production automation.

## Official Android coding-agent skills

- [Google's Android skills repository](https://github.com/android/skills)
- [A2UI repository contributor skills](https://github.com/a2ui-project/a2ui/tree/main/.agents/skills)
- [AGP 9 upgrade skill](https://github.com/android/skills/tree/main/build-system/agp/agp-9-upgrade)
- [XML Views to Compose migration skill](https://github.com/android/skills/tree/main/jetpack-compose/migration/migrate-xml-views-to-jetpack-compose)
- [Compose theming/styles skill](https://github.com/android/skills/tree/main/jetpack-compose/theming/styles)
- [Android testing setup skill](https://github.com/android/skills/tree/main/testing/testing-setup)
- [Edge-to-edge skill](https://github.com/android/skills/tree/main/system/edge-to-edge)
- [Android CLI skill](https://github.com/android/skills/tree/main/devtools/android-cli)

At inspected commit `b1f707d90904129b5972b3cc6436b568583effe5`, Google's `android/skills`
repository had no A2UI adoption skill. The A2UI repository contains maintainer skills for audits,
issue remediation, releases, and implementing new SDKs, plus catalog-generation fixtures; none is a
workflow for converting an existing Android product to the published AndroidX renderer.

## Source priority when facts conflict

1. Published artifact metadata and API signatures.
2. AndroidX release notes for that artifact version.
3. Android developer A2UI guides.
4. Compatible `v0_9_1` protocol schemas.
5. AndroidX source at the release commit.
6. Samples, then community discussions.

Do not use `lmee/A2UI-Android` as an implementation dependency or source of truth for this skill.
The official A2UI ecosystem page identifies it as a community renderer and, at verification time,
lists it as v0.8 rather than v0.9 compatible.
