# Testing and acceptance

No single test proves an A2UI integration. Use layered gates.

## 1. Static and protocol checks

- Pin AndroidX artifacts and the A2UI protocol version.
- Validate every checked-in JSONL fixture.
- Validate server output against the official v0.9.1 message and catalog schemas.
- Reject unknown components, properties, actions, protocols, and catalogs.
- Check component references, root existence, duplicate IDs, and delete/update order.

The bundled validator is a fast repository check:

```bash
python3 scripts/validate_jsonl.py path/to/file.jsonl
```

For full validation, fetch the pinned official schemas and enable JSON Schema mode:

```bash
scripts/fetch_official_schemas.sh /tmp/a2ui-v0_9_1
python3 scripts/validate_jsonl.py path/to/file.jsonl \
  --schema-root /tmp/a2ui-v0_9_1
```

The fast structural mode is intentionally defensive; production servers must also
validate against the official JSON Schema.

## 2. Processor and state tests

Test transcripts that:

- create, update, and delete surfaces;
- update data-bound properties after initial render;
- update a component tree incrementally;
- create more than one surface;
- reuse IDs in allowed and forbidden ways;
- reference missing components;
- omit a root or delete the root;
- include malformed JSON or an unsupported message;
- cancel during stream collection;
- reconnect and replay according to the chosen policy.

Assert both state and reported errors. A test that only checks "did not crash" is
not sufficient.

## 3. Compose renderer tests

Use `androidx.a2ui.compose:compose-ui-testing` and Compose UI testing to:

- find components through stable semantics/test tags;
- assert displayed values and accessibility roles;
- click/type/select and assert the exact outbound action;
- assert two-way bound values update;
- assert content disappears or changes after incremental updates;
- validate custom catalog components independently;
- verify the app-owned loading, offline, and error UI.

Avoid tests that depend on private implementation node structure.

## 4. Transport contract tests

Run the same corpus against the fixture and remote transport. Verify:

- partial network chunks are reassembled into JSONL messages;
- ordering and cancellation;
- authentication refresh;
- reconnect/resume/replay behavior;
- message size, count, rate, and timeout limits;
- action idempotency and duplicate delivery;
- backpressure and slow-consumer behavior;
- trace correlation and redaction.

## 5. Native action tests

Use fake coordinators for deterministic unit tests and targeted instrumentation for
real Android APIs. Cover the matrix in [native-actions.md](native-actions.md).
Assert that unknown or unauthorized actions fail closed.

## 6. Visual and adaptive tests

Create screenshot baselines for each important catalog component and representative
surface at:

- compact and expanded widths;
- light and dark themes;
- default and large font scales;
- left-to-right and right-to-left layout where supported;
- short, long, empty, loading, partial, error, and offline content;
- representative media success and failure.

Use golden tests to protect the design system, not to lock dynamic copy to one exact
sentence.

## 7. Accessibility tests

- TalkBack reading and traversal order is logical.
- Headings, buttons, links, selection, progress, and error state are exposed.
- Touch targets and contrast meet team policy.
- Dynamic updates are announced only when useful.
- Focus is preserved or intentionally moved after an update.
- Motion respects user settings.

## 8. Security and abuse tests

Exercise:

- unknown function/event names;
- URL scheme/origin bypass attempts;
- oversized/deep component trees and update floods;
- stale, replayed, and cross-session actions;
- altered payment totals and identifiers;
- untrusted media URLs;
- prompt/content injection attempting to invoke native capabilities;
- sensitive data in logs, saved state, crash reports, and analytics.

## Build gate

From the repository root:

```bash
skills/androidx-a2ui-adoption/scripts/verify_androidx_a2ui.sh "$PWD" app
```

Set `RUN_DEVICE_TESTS=1` only when a compatible emulator/device is available.

## Definition of done

- The normal app build and relevant unit/instrumented tests pass.
- The exact AndroidX/protocol/catalog versions are documented.
- At least one complete fixture-driven journey passes end to end.
- The same UI path works with the staging transport.
- User actions are returned and correlated with the right session/surface/component.
- Native capabilities are allowlisted, lifecycle-safe, cancelable, and tested.
- Server and client both reject unsupported/malformed input safely.
- The surface matches the host design system and passes visual/accessibility review.
- Loading, offline, malformed, incompatible, and backend-error states are usable.
- Existing non-A2UI journeys and navigation remain regression-tested.
- Feature flag, telemetry, fallback, rollback, ownership, and runbook exist.

An integration that only renders a happy-path mock fixture is a POC, not complete
production adoption.
