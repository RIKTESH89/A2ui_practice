# Design systems and catalogs

## Why a correct A2UI app can still look generic

The Material 3 Basic Catalog is a protocol baseline. It proves that components can
be described and rendered, but it does not supply the art direction, information
architecture, media, motion, or domain components seen in a polished demo.

If the output resembles stacked outlined cards with default typography, the usual
cause is a Basic-only catalog plus generic payload composition. The fix is not to
hardcode a one-off screen around the renderer. Build a catalog that expresses the
host product's visual language and domain.

## Strategy matrix

| Strategy | Use when | Trade-off |
| --- | --- | --- |
| Basic unchanged | Wiring, protocol smoke tests, early POC | Fast but generic |
| Basic schemas with overridden renderers | Existing app primitives map well to Basic | Familiar schemas with brand styling |
| Hybrid Basic + custom catalog | Most production apps | Flexible; requires catalog governance |
| Custom catalog | Strong domain grammar or strict design system | Best experience; largest client/server contract |

For an Atlas-level travel experience, prefer hybrid or custom.

## Native shell versus dynamic surface

Keep persistent app chrome outside A2UI unless there is a compelling reason:

- system bars, top app bar, navigation, account identity;
- connection/offline state;
- privacy and security indicators;
- global error and fallback UI;
- text composer when it belongs to the product shell.

Use A2UI for the changing content the agent composes: trip hero, itinerary, offer,
comparison, confirmation, contextual form, or assistance card.

## Convert the design system, not screenshots

Inventory existing primitives and tokens:

- color roles and surface hierarchy;
- type scale and font family;
- spacing, shape, elevation, and borders;
- icons and media aspect ratios;
- interaction, selection, loading, and error states;
- animation duration/easing and reduced-motion behavior;
- accessibility semantics and minimum touch targets.

Map catalog renderers to those primitives. Avoid putting raw color, padding, font
size, or arbitrary modifier strings in generated payloads. Styling remains an app
responsibility; the agent chooses semantic components and constrained variants.

## Prefer semantic domain components

Weak catalog:

```text
Column(Card(Text, Text, Row(Button, Button)))
```

Stronger travel catalog:

```text
TripHero(destination, dates, travelers, heroMedia)
ItineraryTimeline(days, events)
RideOffer(vehicleClass, route, pickupTime, total, terms)
ReservationStatus(reference, status, nextAction)
SecurePaymentSummary(merchant, amount, currency, quoteId)
```

The agent can select and populate these components but cannot distort their layout,
brand treatment, or safety semantics. Keep components composable enough for useful
variation without exposing arbitrary UI execution.

## Schema design rules

- Use stable semantic property names.
- Define required fields, defaults, enums, and validation constraints.
- Use resource/media descriptors instead of raw Android object concepts.
- Use opaque backend IDs, not database rows or sensitive records.
- Separate display values from authoritative values used for transactions.
- Define loading, empty, partial, error, and disabled states.
- Version breaking schema changes with a new catalog ID.
- Supply representative and adversarial examples with every component.

## Renderer implementation rules

Each `A2uiComponent` should:

- declare properties with `A2uiProperty`;
- resolve dynamic values with `bind`;
- write two-way values with `bindUpdater` only where needed;
- use stable keys for lists and state;
- expose content descriptions, roles, headings, and state semantics;
- honor app theme, font scale, layout direction, and window size;
- clamp unsafe dimensions/content and handle missing media;
- emit typed, allowlisted actions rather than execute privileged work directly.

Review the official component implementation guide and AndroidX component page for
the pinned version before relying on exact alpha signatures.

## Media and motion

A polished demo needs media and transitions that survive real data:

- Provide authenticated image loading, placeholders, errors, caching, crop rules,
  and content descriptions.
- Provide lifecycle-aware video/audio handlers if the catalog permits them.
- Use app-owned motion inside custom renderers; payloads select constrained motion
  variants rather than arbitrary timing curves.
- Respect reduced-motion/accessibility settings.
- Avoid autoplay with sound and avoid motion that hides loading or transaction
  state.

## Adaptive and accessible by construction

Test every component with:

- narrow phones, foldables/tablets, portrait and landscape;
- 200% font scale and long translated strings;
- TalkBack traversal and labeled actions;
- keyboard/D-pad navigation if supported by the host app;
- light/dark and high-contrast conditions;
- loading, empty, offline, partial, error, and stale-data states.

Do not let the agent choose visual ordering that breaks reading order or lets a
secondary action masquerade as a primary transaction.

## Visual acceptance gate

Before calling a surface product-ready:

- It uses the same token source and components as the rest of the app.
- Visual hierarchy is clear without relying on borders around every block.
- Domain information is grouped into a small number of semantic sections.
- Primary and destructive actions are visually and semantically distinct.
- Media has deliberate aspect ratio, crop, loading, and failure behavior.
- Empty/loading/error states are designed, not raw text.
- Golden tests cover representative device sizes and content extremes.
- A design-system owner has reviewed every catalog renderer and variant.

