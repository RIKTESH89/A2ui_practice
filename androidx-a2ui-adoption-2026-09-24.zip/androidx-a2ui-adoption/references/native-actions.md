# Native actions, biometrics, and payments

## Principle

A2UI may render a request or button that initiates a native capability. The A2UI
payload itself must not implement biometrics, payments, permissions, credentials,
or arbitrary Android API calls.

Use this boundary:

```text
A2UI component event
  -> allowlisted typed app action
  -> app policy and current-state validation
  -> native system UI / SDK
  -> typed result
  -> outbound action or backend request
  -> server-authoritative A2UI update
```

## Action interception

`A2uiActionInterceptor` is suspend middleware around an `A2uiUserAction`. Use it to
validate, transform, enrich, or consume an action before it leaves the surface.
Interceptors block the surface action pipeline, so keep them lightweight. Delegate
long work and Activity-bound system UI to a lifecycle-aware coordinator.

Allowlist event and function names. Parse them into typed application actions. An
unknown action must fail closed and produce a recoverable UI outcome or telemetry;
it must never be dispatched through reflection.

## Biometric prompt

Biometric authentication is feasible in an A2UI-driven journey, but AndroidX
BiometricPrompt renders and controls the fingerprint/face system UI. A2UI only
requests the operation and renders the result state.

Implementation requirements:

1. A custom or Basic button emits a constrained action such as
   `request_biometric` with a purpose code, not arbitrary prompt text or crypto
   material.
2. The app verifies that the surface, session, user, and requested purpose are
   currently eligible.
3. A coordinator with a foreground `FragmentActivity` invokes `BiometricPrompt`.
4. Prompt title/subtitle/negative-button policy comes from trusted app resources or
   server policy, not unrestricted model text.
5. Map success, cancel, lockout, unavailable, and error into a typed result.
6. Send only the result or an attestation/token required by the business flow. Never
   send biometric data; Android does not expose it to the app.
7. The server re-authorizes the intended operation and sends the resulting surface
   update.

Handle rotation, backgrounding, multiple taps, cancellation, process death, and an
Activity that is no longer in a valid lifecycle state.

## Payment

Separate these concepts:

- `PaymentSummary` is display UI and may be an A2UI component.
- `Confirm purchase` may emit an A2UI event.
- Payment-sheet/system-wallet UI belongs to the native payment provider SDK.
- Biometric confirmation, if used, belongs to the platform/provider flow.
- Price, currency, merchant, quote validity, entitlement, and settlement are
  server-authoritative.

A safe sequence is:

```text
Server creates signed/expiring quote
 -> A2UI renders trusted summary fields
 -> user taps confirm
 -> app validates quote/session/action
 -> native payment sheet or biometric prompt
 -> provider token/result sent directly to authorized backend
 -> backend verifies and executes idempotently
 -> backend streams success/failure A2UI state
```

Never accept a payable total solely from an A2UI payload. Never put card data,
payment secrets, keystore secrets, or provider private keys in A2UI state.

## Other platform capabilities

### Navigation

Map catalog-defined destinations to typed navigation routes. Validate IDs and user
authorization. Do not accept arbitrary route strings that can reach internal/debug
screens.

### URLs

Require HTTPS, enforce origin allowlists, strip dangerous schemes, and decide
whether content belongs in a Custom Tab, trusted WebView, or external browser. Make
the destination visible when phishing risk exists.

### Runtime permissions

The app decides whether the capability is relevant and when to show rationale.
A2UI may request a semantic capability but cannot bypass Android permission policy.
Return granted, denied, permanently denied, or unavailable as typed states.

### Camera, location, files, contacts, and sharing

Use constrained purpose-specific app actions, data minimization, foreground
lifecycle checks, and explicit user confirmation. Never expose a generic "invoke
Android intent" function to the agent.

## Testing native bridges

Test every bridge with a fake coordinator and with the real system UI where
instrumentation permits:

- allowed success;
- user cancellation;
- unavailable hardware/service;
- policy rejection;
- stale/duplicate action;
- lifecycle interruption;
- malformed parameters;
- server rejection after local success;
- no sensitive values in logs or saved state.

