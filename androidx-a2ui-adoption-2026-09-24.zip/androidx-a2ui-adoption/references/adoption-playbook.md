# Adoption playbook

Use this playbook to introduce A2UI into an existing Android application without
discarding its architecture, navigation, design system, or native security
boundaries.

## Phase 0: inventory the host app

Run:

```bash
skills/androidx-a2ui-adoption/scripts/preflight.sh /absolute/path/to/repository
```

Record:

- Android Gradle Plugin, Gradle, Kotlin, compile SDK, min SDK, and Java versions.
- Modules that own UI, networking, navigation, authentication, and design tokens.
- Compose, XML, and hybrid screen counts.
- Existing dependency injection, serialization, transport, analytics, and test
  libraries.
- User journeys that are safe for an agent to compose dynamically.
- Operations that must remain deterministic and native, including credentials,
  biometrics, payment confirmation, permissions, and external navigation.

Do not start by replacing the whole app. Select one bounded, reversible surface.

## Phase 1: define the first vertical slice

Write down one complete journey:

1. What user request starts it?
2. Which catalog components can appear?
3. Which data may be displayed?
4. Which events can be emitted?
5. Which events require a native capability?
6. What is the deterministic fallback if the stream fails?

Good first slices are an itinerary, support flow, product comparison, or account
summary. Avoid moving login, checkout authorization, or irreversible operations
into the first experiment.

The vertical slice is complete only when it renders from a recorded JSONL fixture,
emits an outbound action, passes through a native action policy, and can swap the
fixture transport for a remote transport without changing UI code.

## Phase 2: choose the catalog strategy

Use the decision table in [design-and-catalogs.md](design-and-catalogs.md).

- Use Basic Catalog unchanged only for protocol plumbing and smoke tests.
- Override Basic component implementations to adopt the host design system while
  retaining Basic schemas.
- Add a custom catalog for branded or domain-specific components.
- Use a hybrid catalog when standard primitives and domain components are both
  useful.

Treat catalog schemas as an API contract. Version and review changes.

## Phase 3: satisfy the alpha toolchain

Apply the exact requirements from [compatibility.md](compatibility.md). Prefer a
small, reviewable toolchain change before adding A2UI application code. Build the
existing app after each toolchain change so unrelated migration failures remain
separable from A2UI failures.

Add only the artifacts needed by the chosen strategy:

- `androidx.a2ui.compose:compose-runtime` and
  `androidx.a2ui.compose:compose-ui` for the Compose renderer.
- `androidx.compose.material3:material3-a2ui` for the Basic Material catalog.
- `androidx.a2ui:a2ui` for core/runtime APIs when required directly.
- `androidx.a2ui.compose:compose-ui-testing` in instrumented tests.

Do not copy the renderer source into the product unless the team has explicitly
chosen to maintain a fork.

## Phase 4: establish replaceable client boundaries

Implement the boundaries in [client-architecture.md](client-architecture.md):

- `A2uiTransport` owns bytes, reconnection, authentication, and framing.
- `A2uiSession` owns one processor and its lifecycle.
- The catalog registry owns component definitions and handlers.
- The native action coordinator owns privileged or platform work.
- Compose observes processor state and renders `A2uiSurface`.

The mock transport and live transport must implement the same interface. The
ViewModel and composables must not know which one is active.

## Phase 5: prove the protocol with fixtures

Start with a version-controlled JSONL transcript. Validate it with:

```bash
python3 skills/androidx-a2ui-adoption/scripts/validate_jsonl.py \
  app/src/main/assets/a2ui/scenario.jsonl
```

Prove these cases:

- create a surface;
- add/update components and data;
- render the root;
- emit an event from a user action;
- process a later update to the same surface;
- delete a surface;
- show a deterministic failure state for malformed or rejected input.

Keep fixture replay asynchronous. A fixture that pushes the whole transcript on
the main thread can hide lifecycle and backpressure bugs.

## Phase 6: integrate outbound actions and native capabilities

Collect `outboundEvents`; otherwise the UI can appear but cannot participate in an
agent loop. Route all events through an allowlisted application boundary. Use an
`A2uiActionInterceptor` for lightweight transformation or rejection and a native
coordinator for work requiring an Activity, user confirmation, or a system UI.

Follow [native-actions.md](native-actions.md) for biometrics, payment, navigation,
URLs, permissions, and other sensitive operations.

## Phase 7: integrate a real agent/backend

Use [agent-and-backend.md](agent-and-backend.md). The Android client should change
only the transport binding and environment configuration. Keep the fixture
transport as an offline demo, test fixture, and incident-reproduction tool.

The server must generate only components present in an agreed catalog, honor the
client's capabilities, and consume structured user actions. Do not ask a model to
invent arbitrary Compose or Kotlin code at runtime.

## Phase 8: make it look like the product

Basic Catalog defaults prove rendering; they do not recreate a polished marketing
demo. Apply the host tokens, typography, spacing, media treatment, motion,
accessibility semantics, and domain components described in
[design-and-catalogs.md](design-and-catalogs.md).

Use screenshot baselines on the team's representative devices. Include large font,
dark mode, narrow width, landscape, and long/translated content.

## Phase 9: harden and verify

Use every applicable layer in [testing-and-acceptance.md](testing-and-acceptance.md):

- schema and fixture validation;
- processor/state tests;
- Compose interaction tests;
- transport contract tests;
- native action policy tests;
- accessibility and screenshot tests;
- full build and device smoke test.

Run:

```bash
skills/androidx-a2ui-adoption/scripts/verify_androidx_a2ui.sh \
  /absolute/path/to/repository app
```

## Phase 10: document ownership and rollout

Before production rollout, record:

- the exact AndroidX and A2UI protocol versions;
- catalog IDs, schemas, owners, and compatibility policy;
- backend/transport endpoints and authentication mechanism;
- permitted native actions and their owners;
- telemetry fields with privacy classification;
- rollback and non-A2UI fallback behavior;
- release gates and on-call troubleshooting notes.

Roll out behind a feature flag. Treat protocol parse failures, unsupported
components, security rejections, and native-action failures as separate metrics.
