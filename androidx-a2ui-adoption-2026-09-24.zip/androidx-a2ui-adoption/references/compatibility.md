# Compatibility snapshot: AndroidX A2UI alpha01

Verified on 2026-09-24. Re-check the official release pages before changing any version.

## Supported stack

| Concern | Required or verified value |
|---|---|
| AndroidX A2UI release | `1.0.0-alpha01` |
| Supported wire protocol | A2UI `v0.9.1` (messages accept `"v0.9"` and `"v0.9.1"`) |
| Canonical Basic Catalog ID | `https://a2ui.org/specification/v0_9/catalogs/basic/catalog.json` |
| Minimum Android SDK | 24 (from the published Compose UI AAR manifest) |
| Compile SDK | 37 with minor 1 (`compileSdk = 37`, `compileSdkMinor = 1`) |
| Minimum Android Gradle Plugin | 9.1.0 (from AAR metadata) |
| Kotlin used by artifacts | 2.2.20 |
| Compose runtime/UI used by artifacts | 1.13.0-alpha03 |
| Material 3 used by `material3-a2ui` | 1.5.0-alpha28 |
| Lifecycle runtime used by Compose UI | 2.10.0 |

Do not infer that library version `1.0.0-alpha01` means protocol `v1.0`. The AndroidX release
currently implements protocol `v0.9.1`.

## Artifacts

Use Google Maven and pin the artifacts needed by the app:

```kotlin
dependencies {
    implementation("androidx.a2ui:a2ui-model:1.0.0-alpha01")
    implementation("androidx.a2ui:a2ui-engine:1.0.0-alpha01")
    implementation("androidx.a2ui.compose:compose-runtime:1.0.0-alpha01")
    implementation("androidx.a2ui.compose:compose-ui:1.0.0-alpha01")
    implementation("androidx.compose.material3:material3-a2ui:1.0.0-alpha01")

    androidTestImplementation(
        "androidx.a2ui.compose:compose-ui-testing:1.0.0-alpha01"
    )
}
```

Some dependencies are transitive, but explicit entries make the adopted layers and upgrade surface
clear. Reconcile versions with Gradle dependency insight rather than forcing incompatible Compose
versions through a BOM.

## Public entry points used by an app

- `androidx.a2ui.compose.runtime.A2uiMessageParser()` parses raw JSON strings.
- `androidx.a2ui.compose.ui.A2uiMessageProcessor(...)` creates the Compose-backed processor.
- `A2uiMessageProcessor.collectMessages()` runs the processing loop.
- `A2uiMessageProcessor.processInput(parser, json)` parses, validates, and queues a message.
- `A2uiMessageProcessor.activeSurfaces` exposes renderable surface models.
- `A2uiMessageProcessor.outboundEvents` emits events and client errors for the backend.
- `androidx.compose.material3.a2ui.A2uiSurface(...)` renders a surface.
- `materialA2uiBasicCatalogV1(...)` creates the supplied Material 3 Basic Catalog.
- `A2uiActionInterceptor` can transform or consume user actions before core handling.
- `A2uiTestController(...)` supports Compose UI tests for catalogs/components.

The public `A2uiMessageProcessor` interface does not expose the concrete core processor's
`clientCapabilities` property. An app-owned transport contract can derive advertised catalog IDs
from the same registered catalog list until a public convenience API is available.

## Basic Catalog implementation requirements

`materialA2uiBasicCatalogV1` requires the host to provide:

- image renderer;
- video renderer;
- audio-player renderer;
- URL opener;
- message formatter;
- locale provider.

The library intentionally avoids choosing Coil/Glide/Media3/network dependencies. Empty handlers
are acceptable only for a narrow fixture that never emits those components or functions.

## Do not mix with A2UI v1.0

The `a2ui-project/a2ui` default branch includes `specification/v1_0`, which adds new message forms,
typed bidirectional function calls, different capabilities, and catalog behavior. These are not a
drop-in input for AndroidX alpha01. For alpha01 payload validation, use the repository's
`specification/v0_9_1` schemas and examples.

## Upgrade procedure

1. Read the AndroidX A2UI, A2UI Compose, and Material3-A2UI release notes.
2. Inspect each new AAR's `aar-metadata.properties` and POM/Gradle module metadata.
3. Confirm the supported A2UI protocol and canonical catalog ID in source or docs.
4. Update schema fixtures and the agent catalog prompt together.
5. Run JSON/schema, processor, component, screenshot, and device tests before switching production.
6. Keep the previous catalog registered during a negotiated transition when the new release allows
   both versions.
