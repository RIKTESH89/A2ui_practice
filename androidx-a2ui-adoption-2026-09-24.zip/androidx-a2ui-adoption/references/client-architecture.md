# Android client architecture

## Boundary map

```text
Agent/backend or fixture
          |
          v
    A2uiTransport  -- auth, bytes, JSONL framing, retries
          |
          v
 A2uiMessageParser -- protocol decoding and parse errors
          |
          v
A2uiMessageProcessor -- surface state and outbound actions
          |                           |
          v                           v
   A2uiSurface                Action policy/interceptor
          |                           |
          v                           v
 Compose catalog                 Native coordinator
                                      |
                        biometrics, payment, navigation,
                        permissions, URLs, app services
```

The AndroidX renderer owns protocol state and Compose rendering. The application
still owns transport, product policy, sensitive operations, visual identity,
telemetry, and fallback behavior.

## Transport contract

Keep the contract independent of AndroidX so fixtures and production use the same
client path:

```kotlin
interface A2uiTransport {
    val incomingJsonLines: Flow<String>
    suspend fun connect(capabilities: ClientCapabilities)
    suspend fun send(actionJson: String)
    fun close()
}

data class ClientCapabilities(
    val protocolVersion: String,
    val catalogIds: Set<String>,
    val extensions: Set<String> = emptySet(),
)
```

Recommended implementations:

- `AssetFixtureA2uiTransport` for deterministic demos and tests.
- `RecordingA2uiTransport` decorator for sanitized incident replay.
- `RemoteA2uiTransport` for HTTP streaming, SSE, WebSocket, A2A, or AG-UI.

The transport must preserve JSONL message boundaries. Do not concatenate partial
network chunks and assume each chunk is one message. Add explicit framing,
size/time limits, cancellation, authentication refresh, and reconnect policy.

## Session ownership

Create one processor per logical A2UI conversation/session. Keep its lifetime in a
ViewModel or another lifecycle-aware owner, not in a recomposing function.

Conceptual shape (verify names against the pinned API before copying):

```kotlin
class A2uiSessionViewModel(
    private val transport: A2uiTransport,
    private val parser: A2uiMessageParser,
    catalog: A2uiCatalog,
) : ViewModel() {
    val processor = A2uiMessageProcessor(catalogs = listOf(catalog))

    init {
        viewModelScope.launch {
            transport.incomingJsonLines
                .collect { line -> processor.processInput(parser, line) }
        }
        viewModelScope.launch {
            processor.outboundEvents.collect { action ->
                transport.send(encodeAction(action))
            }
        }
    }

    override fun onCleared() {
        transport.close()
    }
}
```

The official convenience API can collect a stream through `collectMessages`.
Whichever form is used, expose parse, processing, connection, and action-send
failures as separate UI states and metrics.

## Compose boundary

The app shell should remain native and deterministic:

```kotlin
@Composable
fun AgentScreen(session: A2uiSessionViewModel) {
    AppScaffold(
        topBar = { ProductTopBar() },
        offlineContent = { ProductFallback() },
    ) {
        val surfaces by session.processor.activeSurfaces.collectAsState()
        surfaces.forEach { surface ->
            A2uiSurface(surfaceModel = surface)
        }
    }
}
```

Exact parameters can change during alpha; inspect the pinned KDoc/source. The key
boundary is stable: native shell outside, dynamic surface inside.

For XML applications, add Compose at a controlled boundary with `ComposeView`.
Do not convert unrelated screens merely to adopt one A2UI surface.

## Catalog registry

Create catalogs once and inject platform handlers:

- image loading with authentication and cache policy;
- video/audio rendering with lifecycle and autoplay policy;
- allowlisted URL opening;
- localized strings and locale information;
- message-sending behavior where the product permits it;
- custom component renderers and property schemas.

Production handlers must not be empty lambdas. Missing handlers should be explicit,
visible during testing, and safe in release builds.

## Native action pipeline

Use a small typed application action layer between A2UI and product code:

```kotlin
sealed interface ProductAgentAction {
    data class OpenTrip(val tripId: String) : ProductAgentAction
    data class RequestBiometric(val reasonCode: String) : ProductAgentAction
    data class ConfirmPayment(val quoteId: String) : ProductAgentAction
}
```

Map A2UI event/function names through an allowlist. Reject unknown names, missing
fields, invalid identifiers, and out-of-policy requests. Never use reflection or an
unrestricted service locator to execute a model-provided function name.

## Lifecycle, concurrency, and resilience

- Cancel collection with the owning lifecycle.
- Serialize processor updates if the chosen API is not documented as concurrent.
- Define whether reconnect resumes a session, replays it, or starts a new one.
- Deduplicate actions with stable IDs at the server boundary for irreversible work.
- Cap message size, component count, tree depth, media size, and update rate.
- Surface a recoverable app-owned error UI rather than leaving an empty surface.
- Keep a last-known-safe fallback, but do not silently render stale transactional
  state as current.

## Observability

Record sanitized, structured events for:

- transport connect/reconnect/close;
- parse result and protocol version;
- surface create/update/delete;
- component-not-found and property errors;
- outbound action requested/allowed/rejected/completed;
- render latency and update latency;
- native capability result by coarse outcome.

Never log secrets, payment data, biometric material, full prompts, or unredacted
user content. Hash or redact identifiers according to company policy.
