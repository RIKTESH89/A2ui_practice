# Coding-agent handoff prompt

Copy the prompt below into a coding agent that can access the target repository.
Attach or install this entire skill directory, not only this prompt.

---

Use `$androidx-a2ui-adoption` to assess and implement official AndroidX A2UI in this
Android repository.

Goal: deliver a buildable, tested A2UI vertical slice that matches the application's
existing design system and is architected so a fixture transport can be replaced by
a real agent/backend without changing the renderer or screen code.

Requirements:

1. Read the skill and every reference it routes to for the work you perform. Treat
   its compatibility matrix as the version source of truth unless you deliberately
   verify and document a newer compatible AndroidX release.
2. First run the bundled preflight script and inspect repository instructions,
   current architecture, toolchain, UI stack, design system, navigation, networking,
   tests, and dirty worktree. Preserve unrelated user changes.
3. Produce a concise adoption plan and catalog decision before broad edits. Reuse
   the app's components/tokens; do not rebuild the whole app or copy a community
   renderer.
4. Use official `androidx.a2ui` artifacts. For alpha01, use A2UI protocol v0.9.1 and
   do not mix in v1.0 messages from the current A2UI repository main branch.
5. Keep transport, processor/session, catalogs, native action policy, and UI shell as
   separate testable boundaries. A mock JSONL transport and live transport must
   implement the same interface.
6. Use Basic Catalog unchanged only as a smoke test. For production-quality visuals,
   override renderers and/or add a versioned product catalog with semantic domain
   components backed by the existing design system.
7. Collect and test outbound actions. Allowlist actions and route biometrics,
   payments, navigation, permissions, and other privileged capabilities through
   native application coordinators. Never let generated payloads execute arbitrary
   platform APIs.
8. Validate fixtures, compile, run relevant tests, and verify at least one complete
   create/update/action/result journey. Add loading, malformed, offline,
   incompatible, and denied/error behavior.
9. Document exact versions, catalog IDs/schemas, transport/auth contract, allowed
   native actions, security decisions, feature flag, rollback/fallback, and commands
   to reproduce validation.
10. Do not claim completion from a happy-path mock alone. Report remaining backend,
    product, security, or device-test dependencies explicitly.

Before editing, summarize the discovered constraints and selected first vertical
slice. Then implement autonomously within scope. Ask only when a missing product or
security decision would materially change behavior. At the end, give file links,
commands run, test results, and remaining risks.

---

## Suggested repository-specific appendix

Add these facts before handing it off:

- Target module(s):
- First journey/surface:
- Existing design-system package:
- Existing transport/network stack:
- Backend/agent endpoint or "fixture only":
- Required native capabilities:
- Minimum/target SDK constraints:
- Required device matrix:
- Company security/privacy standards:
- Feature-flag system:
- Definition-of-done additions:

