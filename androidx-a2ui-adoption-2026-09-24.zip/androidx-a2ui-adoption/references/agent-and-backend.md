# Agent and backend integration

## What AndroidX A2UI does and does not provide

AndroidX A2UI provides the Android-side protocol parser/processor and Compose
renderer. It does not supply the product's agent, model prompt, tool layer, business
services, transport, authorization system, or transaction backend.

The agent/backend produces A2UI protocol messages conforming to the catalog the
client supports. The client renders them and returns structured user actions.

## Keep mock and production interchangeable

Use this progression:

```text
Recorded JSONL fixture -> in-process mock -> staging agent -> production agent
                 all behind the same A2uiTransport contract
```

Fixtures remain valuable after a live backend exists: they power deterministic UI
tests, demos, regressions, and incident replay.

## Catalog negotiation

The client and server must agree on:

- A2UI protocol version;
- accepted catalog IDs and catalog versions;
- optional extensions;
- product or platform capabilities that affect output.

In the current alpha, model this metadata in the application's session handshake if
the transport does not provide it. The server must never assume a component exists
because another client supports it.

Negotiation is not proven by hardcoded JSON. A fixture proves that a known transcript
renders against a known client. Live negotiation is proven only when the server
receives client capabilities and changes or rejects its output appropriately.

Test negotiation with at least these cases:

- exact protocol/catalog match;
- supported protocol but only Basic Catalog;
- supported protocol with Basic plus product catalog;
- unknown catalog requested;
- incompatible protocol version;
- an optional native capability absent or denied.

## Transport choices

A2UI is transport-agnostic. Choose based on the product architecture:

- HTTP request/response for finite transcripts;
- SSE for simple server-to-client streaming plus a separate action endpoint;
- WebSocket for bidirectional sessions;
- A2A or AG-UI when the broader agent system already uses those protocols.

Regardless of transport, specify:

- authentication and refresh;
- message framing and ordering;
- size/rate/time limits;
- resume/replay semantics;
- idempotency for user actions;
- cancellation and app background behavior;
- error taxonomy and safe fallback;
- trace IDs and redacted observability.

## Agent contract

Give the agent:

- the exact catalog schemas and concise descriptions;
- examples of valid complete and incremental surface updates;
- business tools with typed arguments and authorization enforced server-side;
- rules for when to ask the user rather than infer;
- constraints on sensitive content and irreversible actions;
- recovery behavior for protocol/client errors.

Do not give it an unconstrained instruction such as "generate a beautiful screen."
The model should choose from a finite semantic catalog and provide valid properties.

## Recommended server pipeline

```text
User request/action
  -> authenticate and load authorized context
  -> agent reasoning and typed business tools
  -> catalog-constrained A2UI generation
  -> schema + policy validation
  -> JSONL stream to client
  -> client action returned with session/surface/action ID
  -> authenticate, authorize, deduplicate, execute
  -> stream resulting state update
```

Validation is mandatory after model generation. Model output is untrusted even when
it was prompted with the schema.

## ADK relationship

Google's Agent Development Kit can host an agent that produces A2UI messages, and
the official A2UI repository contains ADK-oriented samples/guidance. ADK is not a
runtime dependency of the Android renderer. Another backend stack can be used if it
honors the same protocol, catalogs, and security rules.

If adopting ADK, inspect the official repository's current agent and remote-agent
guides from [official-sources.md](official-sources.md); those may evolve separately
from AndroidX alpha01.

## Server-side security rules

- Re-authorize every sensitive action server-side; client presentation is not
  authorization.
- Never trust prices, entitlements, account IDs, or payment totals echoed by UI.
- Bind an action to user, session, surface, component, current quote/version, and an
  expiry where applicable.
- Use idempotency keys for bookings, orders, transfers, and other irreversible work.
- Reject unknown catalogs, components, properties, actions, and oversized payloads.
- Sanitize URLs and media origins; use short-lived signed URLs when appropriate.
- Keep model/tool credentials off the Android client.

## Contract test matrix

Maintain a shared test corpus containing:

- one happy-path transcript per user journey;
- each supported incremental update type;
- each outbound action and backend response;
- every native-capability branch (allowed, denied, canceled, unavailable);
- malformed, partial, out-of-order, duplicate, and oversized messages;
- catalog and protocol mismatch cases;
- redaction examples proving sensitive fields are not logged.

