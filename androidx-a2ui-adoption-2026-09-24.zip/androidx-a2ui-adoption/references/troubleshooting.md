# Troubleshooting

## Dependency resolution or metadata failure

Symptoms include compile SDK or Android Gradle Plugin compatibility errors before
compilation. Confirm the exact requirements in [compatibility.md](compatibility.md).
The published alpha01 AAR declares compile SDK 37.1 and AGP 9.1.0 minimums. Do not
hide these failures by disabling metadata checks.

If corporate repositories mirror Maven artifacts, verify all three AndroidX A2UI
artifacts and their Compose/Material dependencies are present.

## Protocol messages parse but nothing renders

Check, in order:

1. The payload uses v0.9.1 rather than the repository's current v1.0 shape.
2. `createSurface` uses a catalog registered by the client.
3. The surface ID given to `A2uiSurface` matches the transcript.
4. A root component exists and all referenced component IDs exist.
5. Message collection is active in a lifecycle scope.
6. Parser/processor errors are observed instead of discarded.
7. The surface has measurable layout constraints.

## A fixture works but a live stream fails

- Verify JSONL boundaries; a network chunk is not necessarily a complete line.
- Compare the negotiated protocol/catalog IDs with the fixture.
- Log redacted message type, size, session ID, surface ID, and parse result.
- Check ordering, reconnect/replay policy, and duplicate `createSurface` messages.
- Ensure auth refresh does not silently replace the stream while leaving old
  collectors active.

## UI renders but actions do nothing

- Collect `outboundEvents` for the same processor that rendered the surface.
- Verify the renderer emits the action type expected by the backend.
- Check interceptor order and whether one consumed the action.
- Check that the action is encoded, sent, authorized, correlated, and responded to.
- Confirm a custom component uses `bindUpdater` where two-way state is required.

## UI looks like a generic stack of cards

This is usually a catalog/design problem, not a renderer defect. Do not chase the
marketing demo by adding random padding to a Basic-only payload. Follow
[design-and-catalogs.md](design-and-catalogs.md): use app tokens, override renderers,
create semantic domain components, supply media handlers, and add visual gates.

## Images, audio, video, URLs, or messages do nothing

The Basic Material catalog requires host-provided handlers for these capabilities.
Replace demo no-ops with production implementations that enforce authentication,
origin, lifecycle, privacy, and user-confirmation policy.

## Biometric prompt does not appear or leaks lifecycle errors

- A2UI cannot render the system prompt itself; use AndroidX BiometricPrompt.
- Invoke it from a foreground lifecycle-aware Activity/Fragment coordinator.
- Reject double taps and stale actions.
- Do not retain an Activity in a ViewModel or catalog singleton.
- Handle background/cancel/rotation/process-death paths.

## Processor or UI is recreated unexpectedly

Do not instantiate the processor, catalog, transport, or message collector inside a
recomposing body. Own the session in a ViewModel or a stable lifecycle owner and use
keys intentionally.

## Scrolling or focus behaves badly

- Avoid nesting an unconstrained lazy container inside another vertical scroller.
- Give custom components stable keys.
- Preserve focus across incremental state updates.
- Keep the app composer/system inset handling outside the dynamic surface when that
  produces a clearer ownership boundary.

## Server emits unsupported components

Capture the negotiated catalog list and offending component name. Treat this as a
contract failure. The server should regenerate or fall back to a mutually supported
catalog, not make the client silently guess a renderer.

## Alpha API signature differs from sample code

Use the AndroidX alpha release page and linked source for the pinned artifact.
Examples from `a2ui-project/a2ui` may target v1.0 or another renderer and are not
automatically source-compatible with AndroidX alpha01. Update this skill's
compatibility matrix and templates only after the target app passes build and
contract tests.

## Escalation bundle

When escalating, provide:

- sanitized failing JSONL transcript;
- AndroidX/protocol/catalog versions;
- toolchain versions and module dependency report;
- redacted parser/processor error and trace ID;
- whether the fixture and live transport differ;
- device/API level, theme, font scale, and window size for visual issues;
- minimal custom component/handler involved;
- expected and actual lifecycle/action sequence.

