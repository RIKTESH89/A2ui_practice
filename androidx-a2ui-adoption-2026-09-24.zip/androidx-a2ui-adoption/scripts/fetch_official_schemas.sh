#!/usr/bin/env bash
set -eu

destination="${1:-}"
if [ -z "$destination" ]; then
  echo "Usage: $0 /absolute/output/directory" >&2
  exit 2
fi
if ! command -v curl >/dev/null 2>&1; then
  echo "ERROR: curl is required" >&2
  exit 2
fi

commit="a204b8a7824c6ef523ba6470369990774e21e5b9"
base="https://raw.githubusercontent.com/a2ui-project/a2ui/$commit/specification/v0_9_1"

mkdir -p "$destination/json" "$destination/catalogs/basic"

curl --fail --location --silent --show-error \
  "$base/json/server_to_client.json" \
  --output "$destination/json/server_to_client.json"
curl --fail --location --silent --show-error \
  "$base/json/common_types.json" \
  --output "$destination/json/common_types.json"
curl --fail --location --silent --show-error \
  "$base/catalogs/basic/catalog.json" \
  --output "$destination/catalogs/basic/catalog.json"

echo "Downloaded the pinned official v0.9.1 schemas to $destination"

