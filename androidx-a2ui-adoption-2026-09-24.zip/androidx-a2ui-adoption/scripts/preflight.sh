#!/usr/bin/env bash
set -u

repo="${1:-.}"
module="${2:-app}"

if ! repo="$(cd "$repo" 2>/dev/null && pwd -P)"; then
  echo "ERROR: repository directory does not exist: ${1:-.}" >&2
  exit 2
fi

search() {
  pattern="$1"
  shift
  if command -v rg >/dev/null 2>&1; then
    rg -n --hidden --glob '!**/.git/**' --glob '!**/build/**' \
      --glob '!**/androidx-a2ui-adoption/**' "$pattern" "$@" 2>/dev/null || true
  else
    grep -RInE --exclude-dir=.git --exclude-dir=build \
      --exclude-dir=androidx-a2ui-adoption "$pattern" "$@" 2>/dev/null || true
  fi
}

echo "# AndroidX A2UI preflight"
echo
echo "Repository: $repo"
echo "Requested module: $module"
echo

echo "## Repository state"
if git -C "$repo" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  git -C "$repo" status --short || true
  echo "Branch: $(git -C "$repo" branch --show-current 2>/dev/null || true)"
  echo "Commit: $(git -C "$repo" rev-parse --short HEAD 2>/dev/null || true)"
else
  echo "Not a Git worktree."
fi
echo

echo "## Build entry points"
find "$repo" -maxdepth 3 -type f \( \
  -name 'settings.gradle' -o -name 'settings.gradle.kts' -o \
  -name 'build.gradle' -o -name 'build.gradle.kts' -o \
  -name 'gradle-wrapper.properties' -o -name 'libs.versions.toml' \
\) -print 2>/dev/null | sort
echo

echo "## Toolchain and Android declarations"
search 'com\.android\.(application|library)|com\.android\.tools\.build:gradle|agp[[:space:]]*=|kotlin[[:space:]]*=|compileSdk|compileSdkMinor|minSdk|targetSdk|jvmTarget|JavaVersion|org\.gradle\.java\.home' "$repo" | head -240
echo

echo "## UI, architecture, transport, and test dependencies"
search 'androidx\.compose|compose-bom|material3|navigation-compose|hilt|koin|dagger|retrofit|ktor|okhttp|serialization|moshi|gson|robolectric|paparazzi|roborazzi|screenshot|espresso|ui-test' "$repo" | head -320
echo

echo "## Existing A2UI references"
search 'androidx\.a2ui|material3-a2ui|A2ui|A2UI|a2ui' "$repo" | head -320
echo

echo "## UI source inventory"
compose_count=$(find "$repo" -type f \( -name '*.kt' -o -name '*.java' \) -not -path '*/build/*' -exec grep -l '@Composable' {} + 2>/dev/null | wc -l | tr -d ' ')
xml_layout_count=$(find "$repo" -path '*/src/*/res/layout/*.xml' -type f 2>/dev/null | wc -l | tr -d ' ')
manifest_count=$(find "$repo" -name AndroidManifest.xml -not -path '*/build/*' 2>/dev/null | wc -l | tr -d ' ')
echo "Files containing @Composable: $compose_count"
echo "XML layout files: $xml_layout_count"
echo "Android manifests: $manifest_count"
echo

echo "## Design-system candidates"
find "$repo" -type f \( -name '*Theme*.kt' -o -name '*Color*.kt' -o -name '*Typography*.kt' -o -name '*Shape*.kt' -o -name '*Dimen*.kt' -o -name 'themes.xml' -o -name 'styles.xml' \) -not -path '*/build/*' -print 2>/dev/null | head -160
echo

echo "## A2UI alpha01 readiness"
readiness_target="$repo/$module"
if [ ! -d "$readiness_target" ]; then
  readiness_target="$repo"
fi
if search 'compileSdk[^0-9]*37|compileSdkVersion[^0-9]*37' "$readiness_target" | grep -q .; then
  echo "PASS candidate: compile SDK 37 found. Confirm minor API level 1."
else
  echo "ACTION: alpha01 Compose UI AAR requires compile SDK 37.1."
fi
if search '9\.1\.[0-9]|agp[^0-9]*9\.1' "$repo" | grep -q .; then
  echo "PASS candidate: AGP 9.1.x found."
else
  echo "ACTION: alpha01 Compose UI AAR declares minimum AGP 9.1.0."
fi
if search 'minSdk[^0-9]*([0-9]|1[0-9]|2[0-3])([^0-9]|$)' "$readiness_target" | grep -q .; then
  echo "ACTION: alpha01 Compose UI manifest requires min SDK 24."
else
  echo "PASS candidate: no min SDK below 24 was detected. Confirm resolved variant."
fi
echo
echo "Preflight is read-only. Review findings manually; regex checks do not resolve Gradle variants."
