#!/usr/bin/env bash
set -eu

repo="${1:-.}"
module="${2:-app}"
script_dir="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"

if ! repo="$(cd "$repo" 2>/dev/null && pwd -P)"; then
  echo "ERROR: repository directory does not exist: ${1:-.}" >&2
  exit 2
fi
if [ ! -x "$repo/gradlew" ]; then
  echo "ERROR: Gradle wrapper is missing or not executable: $repo/gradlew" >&2
  exit 2
fi

"$script_dir/preflight.sh" "$repo" "$module"

fixture_count=0
while IFS= read -r fixture; do
  fixture_count=$((fixture_count + 1))
  python3 "$script_dir/validate_jsonl.py" "$fixture"
done < <(find "$repo" -type f -name '*.jsonl' -not -path '*/build/*' -not -path '*/.gradle/*' 2>/dev/null | sort)

if [ "$fixture_count" -eq 0 ]; then
  echo "WARNING: no checked-in JSONL fixtures found outside build directories." >&2
fi

module_path="${module#:}"
module_path="${module_path//\//:}"

cd "$repo"
./gradlew --stacktrace ":${module_path}:assembleDebug" ":${module_path}:testDebugUnitTest"

if [ "${RUN_DEVICE_TESTS:-0}" = "1" ]; then
  ./gradlew --stacktrace ":${module_path}:connectedDebugAndroidTest"
else
  echo "Device tests skipped. Set RUN_DEVICE_TESTS=1 with a compatible device/emulator to run them."
fi

echo "AndroidX A2UI verification completed for :${module_path}."

