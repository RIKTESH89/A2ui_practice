#!/usr/bin/env python3
"""Fast structural validator for AndroidX alpha01 A2UI v0.9/v0.9.1 JSONL fixtures.

This catches common fixture/session errors without third-party packages. Production
servers should additionally validate against the official v0.9.1 JSON Schemas.
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Protocol


MESSAGE_KEYS = ("createSurface", "updateComponents", "updateDataModel", "deleteSurface")
SUPPORTED_VERSIONS = {"v0.9", "v0.9.1"}
BASIC_CATALOG_ID = "https://a2ui.org/specification/v0_9/catalogs/basic/catalog.json"


class OfficialValidator(Protocol):
    def iter_errors(self, instance: Any) -> Iterable[Any]: ...


@dataclass
class Surface:
    catalog_id: str
    components: dict[str, dict[str, Any]] = field(default_factory=dict)


def paths(inputs: list[str]) -> Iterable[Path]:
    for raw in inputs:
        candidate = Path(raw)
        if candidate.is_dir():
            yield from sorted(candidate.rglob("*.jsonl"))
        else:
            yield candidate


def component_refs(value: Any, key: str | None = None) -> set[str]:
    refs: set[str] = set()
    single_ref_keys = {"child"}
    list_ref_keys = {"children"}
    if key in single_ref_keys and isinstance(value, str):
        refs.add(value)
    elif key in list_ref_keys and isinstance(value, list):
        refs.update(item for item in value if isinstance(item, str))
    elif isinstance(value, dict):
        for child_key, child_value in value.items():
            refs.update(component_refs(child_value, child_key))
    elif isinstance(value, list):
        for item in value:
            refs.update(component_refs(item))
    return refs


def load_official_validator(schema_root: Path) -> OfficialValidator:
    try:
        from jsonschema import Draft202012Validator
        from referencing import Registry, Resource
    except ImportError as exc:
        raise RuntimeError(
            "--schema-root requires the jsonschema and referencing Python packages"
        ) from exc

    root = schema_root.resolve()
    json_dir = root / "json" if (root / "json").is_dir() else root
    catalog_path = (
        root / "catalogs" / "basic" / "catalog.json"
        if (root / "catalogs" / "basic" / "catalog.json").is_file()
        else root.parent / "catalogs" / "basic" / "catalog.json"
    )
    server_path = json_dir / "server_to_client.json"
    common_path = json_dir / "common_types.json"
    missing = [str(path) for path in (server_path, common_path, catalog_path) if not path.is_file()]
    if missing:
        raise RuntimeError("missing official schema file(s): " + ", ".join(missing))

    server = json.loads(server_path.read_text(encoding="utf-8"))
    common = json.loads(common_path.read_text(encoding="utf-8"))
    catalog = json.loads(catalog_path.read_text(encoding="utf-8"))
    catalog_alias = json.loads(json.dumps(catalog))
    catalog_alias["$id"] = "https://a2ui.org/specification/v0_9/catalog.json"

    registry = Registry()
    for schema in (server, common, catalog, catalog_alias):
        registry = registry.with_resource(schema["$id"], Resource.from_contents(schema))
    return Draft202012Validator(server, registry=registry)


def validate_file(
    path: Path,
    expected_catalog: str | None,
    allow_existing: bool,
    official_validator: OfficialValidator | None,
) -> int:
    errors: list[str] = []
    warnings: list[str] = []
    surfaces: dict[str, Surface] = {}
    created_here: set[str] = set()

    if not path.is_file():
        print(f"ERROR {path}: file not found", file=sys.stderr)
        return 1

    for line_no, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not raw.strip():
            continue
        prefix = f"{path}:{line_no}"
        try:
            message = json.loads(raw)
        except json.JSONDecodeError as exc:
            errors.append(f"{prefix}: invalid JSON: {exc.msg} at column {exc.colno}")
            continue
        if not isinstance(message, dict):
            errors.append(f"{prefix}: message must be a JSON object")
            continue

        if official_validator is not None:
            schema_errors = sorted(
                official_validator.iter_errors(message), key=lambda error: list(error.path)
            )
            for schema_error in schema_errors:
                pointer = "/" + "/".join(str(part) for part in schema_error.path)
                errors.append(f"{prefix}: official schema {pointer}: {schema_error.message}")

        version = message.get("version")
        if version not in SUPPORTED_VERSIONS:
            errors.append(f"{prefix}: version must be v0.9 or v0.9.1, got {version!r}")

        present = [key for key in MESSAGE_KEYS if key in message]
        if len(present) != 1:
            errors.append(f"{prefix}: expected exactly one message key from {MESSAGE_KEYS}, got {present}")
            continue
        key = present[0]
        body = message[key]
        if not isinstance(body, dict):
            errors.append(f"{prefix}: {key} must be an object")
            continue
        surface_id = body.get("surfaceId")
        if not isinstance(surface_id, str) or not surface_id.strip():
            errors.append(f"{prefix}: {key}.surfaceId must be a non-empty string")
            continue

        if key == "createSurface":
            catalog_id = body.get("catalogId")
            if not isinstance(catalog_id, str) or not catalog_id:
                errors.append(f"{prefix}: createSurface.catalogId must be a non-empty string")
                continue
            if expected_catalog and catalog_id != expected_catalog:
                errors.append(
                    f"{prefix}: catalogId {catalog_id!r} does not match expected {expected_catalog!r}"
                )
            if surface_id in surfaces:
                errors.append(f"{prefix}: surface {surface_id!r} created more than once without delete")
            surfaces[surface_id] = Surface(catalog_id=catalog_id)
            created_here.add(surface_id)

        elif key == "updateComponents":
            surface = surfaces.get(surface_id)
            if surface is None:
                if not allow_existing:
                    errors.append(f"{prefix}: update references surface {surface_id!r} before create")
                    continue
                surface = Surface(catalog_id=expected_catalog or "<external>")
                surfaces[surface_id] = surface
                warnings.append(f"{prefix}: treating surface {surface_id!r} as externally created")
            components = body.get("components")
            if not isinstance(components, list) or not components:
                errors.append(f"{prefix}: updateComponents.components must be a non-empty array")
                continue
            for index, component in enumerate(components):
                cprefix = f"{prefix}: component[{index}]"
                if not isinstance(component, dict):
                    errors.append(f"{cprefix} must be an object")
                    continue
                component_id = component.get("id")
                component_type = component.get("component")
                if not isinstance(component_id, str) or not component_id:
                    errors.append(f"{cprefix}.id must be a non-empty string")
                    continue
                if not isinstance(component_type, str) or not component_type:
                    errors.append(f"{cprefix}.component must be a non-empty string")
                    continue
                surface.components[component_id] = component

        elif key == "updateDataModel":
            if surface_id not in surfaces and not allow_existing:
                errors.append(f"{prefix}: data update references surface {surface_id!r} before create")
            if "value" not in body:
                errors.append(f"{prefix}: updateDataModel.value is required")
            data_path = body.get("path")
            if data_path is not None and not isinstance(data_path, str):
                errors.append(f"{prefix}: updateDataModel.path must be a string when present")

        elif key == "deleteSurface":
            if surface_id not in surfaces and not allow_existing:
                errors.append(f"{prefix}: delete references unknown surface {surface_id!r}")
            surfaces.pop(surface_id, None)

    for surface_id, surface in surfaces.items():
        if surface_id in created_here and "root" not in surface.components:
            errors.append(f"{path}: active surface {surface_id!r} has no component with id 'root'")
        ids = set(surface.components)
        for component_id, component in surface.components.items():
            for ref in component_refs(component):
                if ref not in ids:
                    errors.append(
                        f"{path}: surface {surface_id!r} component {component_id!r} "
                        f"references missing component {ref!r}"
                    )

    for warning in warnings:
        print(f"WARNING {warning}")
    for error in errors:
        print(f"ERROR {error}", file=sys.stderr)
    if errors:
        print(f"FAIL {path}: {len(errors)} error(s)", file=sys.stderr)
        return 1
    print(f"PASS {path}")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("paths", nargs="+", help="JSONL files or directories")
    parser.add_argument(
        "--catalog-id",
        default=None,
        help=f"require this catalog ID (Basic is {BASIC_CATALOG_ID})",
    )
    parser.add_argument(
        "--allow-existing-surfaces",
        action="store_true",
        help="allow update-only fixture fragments whose create message is external",
    )
    parser.add_argument(
        "--schema-root",
        type=Path,
        help=(
            "optional official specification/v0_9_1 directory (or its json directory) "
            "for full JSON Schema validation"
        ),
    )
    args = parser.parse_args()
    resolved = list(paths(args.paths))
    if not resolved:
        print("ERROR: no JSONL files found", file=sys.stderr)
        return 2
    try:
        official_validator = (
            load_official_validator(args.schema_root) if args.schema_root is not None else None
        )
    except (OSError, ValueError, RuntimeError, json.JSONDecodeError) as exc:
        print(f"ERROR: cannot load official schemas: {exc}", file=sys.stderr)
        return 2
    failures = sum(
        validate_file(
            path,
            args.catalog_id,
            args.allow_existing_surfaces,
            official_validator,
        )
        for path in resolved
    )
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
