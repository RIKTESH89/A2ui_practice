---
name: androidx-a2ui-adoption
description: Assess, migrate, implement, or productionize an existing Android app with Google's official AndroidX A2UI Jetpack Compose renderer. Use for A2UI architecture, Basic/custom catalogs, mock or live transports, agent integration, native action bridges, visual quality, tests, and alpha-version troubleshooting. Do not use for non-Android renderers or for merely generating A2UI payloads without Android client work.
---

# AndroidX A2UI adoption

Build an A2UI feature that fits the existing app rather than replacing its architecture or visual
identity. Treat A2UI as a bounded rendering capability inside the host application. Preserve the
host shell, navigation, business rules, security boundaries, and design system.

## Version lock

Before editing, read [references/compatibility.md](references/compatibility.md). This skill targets
the published AndroidX `1.0.0-alpha01` libraries and A2UI protocol `v0.9.1`. Do not feed the alpha
renderer schemas or examples from A2UI `v1.0`; the current GitHub default branch contains newer,
wire-incompatible material.

If a newer AndroidX A2UI release exists, inspect its release notes and artifact metadata first,
then update the compatibility table and templates before adopting it. Never silently float alpha
versions.

## Select the relevant references

- For any adoption or migration, read
  [references/adoption-playbook.md](references/adoption-playbook.md).
- For processor, ViewModel, lifecycle, transport, and capability negotiation, read
  [references/client-architecture.md](references/client-architecture.md).
- For product-quality visuals, branded Compose components, and catalog selection, read
  [references/design-and-catalogs.md](references/design-and-catalogs.md).
- For an agent/backend, ADK, A2A, AG-UI, mocking, or streaming, read
  [references/agent-and-backend.md](references/agent-and-backend.md).
- For biometric, payments, navigation, URLs, media, or other Android capabilities, read
  [references/native-actions.md](references/native-actions.md).
- For verification or release readiness, read
  [references/testing-and-acceptance.md](references/testing-and-acceptance.md).
- For errors, API ambiguity, or build failures, read
  [references/troubleshooting.md](references/troubleshooting.md).
- When handing the work to another coding agent, use
  [references/handoff-prompt.md](references/handoff-prompt.md).
- Use [references/official-sources.md](references/official-sources.md) as the authoritative link
  index. Prefer those sources over blogs and community renderers.

## Workflow

1. **Inventory without changing behavior.** Run `scripts/preflight.sh <repo> [module]`. Inspect
   Gradle convention plugins/version catalogs, Kotlin and Compose setup, min/compile SDK, UI stack,
   dependency injection, navigation, networking, authentication, design-system modules, target
   workflows, and test infrastructure. Record unrelated dirty files and preserve them.

2. **Define the A2UI boundary.** Identify specific surfaces where agent-generated structure adds
   value. Keep global navigation, app bars, permission prompts, account state, checkout/payment
   authority, and durable business logic in native code. Do not promise to make an entire codebase
   “A2UI” without an explicit surface map and acceptance criteria.

3. **Choose a catalog deliberately.** Use the Material 3 Basic Catalog for a technical spike. For
   production or visual parity with an existing product, use a hybrid or custom catalog backed by
   the app's actual tokens and Compose components. Do not expect Basic Catalog JSON to reproduce a
   marketing demo or a proprietary design system.

4. **Establish the toolchain and dependency floor.** Apply the exact requirements in the
   compatibility reference. Prefer the project's version catalog and convention plugins. Do not
   downgrade or replace unrelated dependencies. Build immediately after this isolated change.

5. **Add a backend-neutral client seam.** Introduce one `A2uiTransport`-like boundary with raw,
   complete inbound JSON messages and typed outbound client messages. Keep parsing and rendering
   out of the transport. Start with fixtures behind that same interface if the backend is absent.

6. **Host the official processor correctly.** Create the parser, catalogs, action interceptors, and
   processor in a lifecycle owner such as a `ViewModel`. Run exactly one `collectMessages()` loop,
   collect `outboundEvents` from the start, feed messages through `processInput`, and render every
   active surface using `A2uiSurface` keyed by surface ID.

7. **Integrate native capabilities through explicit bridges.** Agent payloads may request an
   approved action, but biometrics, payments, permissions, navigation, and credential operations
   remain native. Validate allowlisted action names and arguments before crossing the bridge.

8. **Integrate the agent only after fixtures pass.** Advertise the exact supported catalog IDs.
   Require the server/agent to generate only that protocol/catalog combination. Preserve message
   boundaries when streaming. Send client actions, synchronized data models, and renderer errors
   back on the transport.

9. **Verify in layers.** Validate JSONL fixtures, processor state, outbound actions, custom
   components, screenshot/golden appearance, accessibility, configuration changes, malformed
   payloads, reconnect behavior, and a real device end-to-end flow. Run
   `scripts/verify_androidx_a2ui.sh <repo> [module]` before handoff.

10. **Document the contract.** Check in the catalog ID/schema, protocol version, example payloads,
    transport envelope, native action allowlist, security ownership, test commands, and upgrade
    procedure. A backend team must not need to inspect renderer internals to produce valid messages.

## Non-negotiable rules

- A2UI payloads are declarative data, never executable Kotlin, JavaScript, HTML, or arbitrary URLs.
- Validate every message and catalog property. Treat all agent output as untrusted input.
- Never mix A2UI `v1.0` payloads with AndroidX alpha01's `v0.9.1` processor.
- Create each surface once; update it incrementally; delete it before reusing its ID.
- Use exactly one component with ID `root` per active surface and keep all references resolvable.
- Do not use no-op image, video, audio, URL, or localization handlers in production.
- Do not let agent-provided amounts, product IDs, permissions, routes, or authentication results
  become authoritative. Resolve and verify them against native/backend state.
- Do not put secrets, tokens, payment credentials, biometric data, or sensitive personal data in
  A2UI messages or logs.
- Do not bypass the host app's design system to chase visual similarity. Express visual quality in
  native components and tokens, then expose safe semantic properties through the catalog.
- Alpha APIs can change. Pin versions, isolate usage behind app-owned adapters, and keep fixture and
  UI tests capable of detecting upgrade drift.

## Completion standard

Do not call the migration complete when only a sample card renders. Completion requires a buildable
app, at least one full user workflow, bidirectional action handling, documented capability/catalog
contract, production handlers for used component types, malformed-payload handling, tests at the
transport/processor/component/UI levels, and an explicit list of remaining backend or product
dependencies.
